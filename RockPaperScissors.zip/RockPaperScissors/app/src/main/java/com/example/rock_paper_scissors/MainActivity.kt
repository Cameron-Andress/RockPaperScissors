package com.example.rock_paper_scissors

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toolbar
import androidx.appcompat.app.AppCompatActivity
import androidx.viewbinding.ViewBinding
import com.example.rock_paper_scissors.databinding.ActivityMainBinding

private val ViewBinding.toolbar: Toolbar?
    get() = this.root.findViewById(R.id.toolbar)

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var playerScore = 0
    private var computerScore = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize binding for the layout
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up the action bar
        setSupportActionBar(binding.toolbar)

        // Initialize game buttons and other components
        val btnRock = findViewById<Button>(R.id.btn_rock)
        val btnPaper = findViewById<Button>(R.id.btn_paper)
        val btnScissors = findViewById<Button>(R.id.btn_scissors)
        val btnPlayAgain = findViewById<Button>(R.id.btn_play_again)

        // Set up listeners for Rock, Paper, Scissors buttons
        btnRock.setOnClickListener { playGame("Rock") }
        btnPaper.setOnClickListener { playGame("Paper") }
        btnScissors.setOnClickListener { playGame("Scissors") }
        btnPlayAgain.setOnClickListener { resetGame() }
    }

    private fun setSupportActionBar(toolbar: Toolbar?) {

    }

    // Method for inflating the options menu
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    // Method for handling action bar item clicks
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    // Game logic integration
    private fun playGame(playerChoice: String) {
        val computerChoice = getRandomChoice()
        updateImages(playerChoice, computerChoice)
        val result = determineWinner(playerChoice, computerChoice)
        updateScore(result)
        checkForWinner()
    }

    private fun getRandomChoice(): String {
        val choices = arrayOf("Rock", "Paper", "Scissors")
        return choices.random()
    }

    private fun updateImages(playerChoice: String, computerChoice: String) {
        val playerImageView = findViewById<ImageView>(R.id.player_image)
        val computerImageView = findViewById<ImageView>(R.id.computer_image)

        // Update player image based on choice
        when (playerChoice) {
            "Rock" -> playerImageView.setImageResource(R.drawable.rock_image)
            "Paper" -> playerImageView.setImageResource(R.drawable.paper_image)
            "Scissors" -> playerImageView.setImageResource(R.drawable.scissors_image)
        }

        // Update computer image based on choice
        when (computerChoice) {
            "Rock" -> computerImageView.setImageResource(R.drawable.rock_image)
            "Paper" -> computerImageView.setImageResource(R.drawable.paper_image)
            "Scissors" -> computerImageView.setImageResource(R.drawable.scissors_image)
        }
    }

    private fun determineWinner(playerChoice: String, computerChoice: String): String {
        return when {
            playerChoice == computerChoice -> "Tie"
            playerChoice == "Rock" && computerChoice == "Scissors" -> "Player"
            playerChoice == "Scissors" && computerChoice == "Paper" -> "Player"
            playerChoice == "Paper" && computerChoice == "Rock" -> "Player"
            else -> "Computer"
        }
    }

    private fun updateScore(result: String) {
        val scoreText = findViewById<TextView>(R.id.score)
        when (result) {
            "Player" -> playerScore++
            "Computer" -> computerScore++
        }
        scoreText.text = "Score: Player $playerScore - $computerScore Computer"
    }

    private fun checkForWinner() {
        val resultText = findViewById<TextView>(R.id.result)
        if (playerScore == 10 || computerScore == 10) {
            resultText.text = if (playerScore == 10) "You Win!" else "Computer Wins!"
            disableGameButtons()
        }
    }

    private fun disableGameButtons() {
        findViewById<Button>(R.id.btn_rock).isEnabled = false
        findViewById<Button>(R.id.btn_paper).isEnabled = false
        findViewById<Button>(R.id.btn_scissors).isEnabled = false
        findViewById<Button>(R.id.btn_play_again).visibility = View.VISIBLE
    }

    private fun resetGame() {
        playerScore = 0
        computerScore = 0
        findViewById<TextView>(R.id.score).text = "Score: Player 0 - 0 Computer"
        findViewById<TextView>(R.id.result).text = ""
        findViewById<Button>(R.id.btn_rock).isEnabled = true
        findViewById<Button>(R.id.btn_paper).isEnabled = true
        findViewById<Button>(R.id.btn_scissors).isEnabled = true
        findViewById<Button>(R.id.btn_play_again).visibility = View.GONE
    }
}
